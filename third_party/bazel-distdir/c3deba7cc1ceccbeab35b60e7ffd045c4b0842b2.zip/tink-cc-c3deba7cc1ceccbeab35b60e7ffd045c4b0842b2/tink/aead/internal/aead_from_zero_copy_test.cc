// Copyright 2021 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
///////////////////////////////////////////////////////////////////////////////
#include "tink/aead/internal/aead_from_zero_copy.h"

#include <cstring>
#include <memory>
#include <string>
#include <utility>

#include "gmock/gmock.h"
#include "gtest/gtest.h"
#include "absl/memory/memory.h"
#include "absl/status/status.h"
#include "absl/status/statusor.h"
#include "absl/strings/string_view.h"
#include "absl/types/span.h"
#include "tink/aead/internal/mock_zero_copy_aead.h"
#include "tink/util/status.h"
#include "tink/util/statusor.h"
#include "tink/util/test_matchers.h"

namespace crypto {
namespace tink {
namespace internal {
namespace {

constexpr absl::string_view kPlaintext = "Some data to encrypt.";
constexpr absl::string_view kAssociatedData = "Some associated data.";
constexpr absl::string_view kCiphertext = "37ajhgdahjsdg8653821218236182631";

using ::crypto::tink::test::IsOk;
using ::crypto::tink::test::StatusIs;
using ::testing::_;
using ::testing::Invoke;
using ::testing::Return;
using ::testing::Unused;

TEST(AeadFromZeroCopyTest, EncryptSucceeds) {
  auto mock_zero_copy_aead = std::make_unique<MockZeroCopyAead>();
  EXPECT_CALL(*mock_zero_copy_aead, MaxEncryptionSize(kPlaintext.size()))
      .WillOnce(Return(kCiphertext.size()));
  EXPECT_CALL(*mock_zero_copy_aead, Encrypt(kPlaintext, kAssociatedData, _))
      .WillOnce(Invoke([&](Unused, Unused, absl::Span<char> buffer) {
        memcpy(buffer.data(), kCiphertext.data(), kCiphertext.size());
        return kCiphertext.size();
      }));

  AeadFromZeroCopy aead(std::move(mock_zero_copy_aead));
  absl::StatusOr<std::string> ciphertext =
      aead.Encrypt(kPlaintext, kAssociatedData);
  ASSERT_THAT(ciphertext, IsOk());
  EXPECT_EQ(*ciphertext, kCiphertext);
}

TEST(AeadFromZeroCopyTest, EncryptFailsIfZeroCopyEncryptFails) {
  auto mock_zero_copy_aead = std::make_unique<MockZeroCopyAead>();
  EXPECT_CALL(*mock_zero_copy_aead, MaxEncryptionSize(kPlaintext.size()))
      .WillOnce(Return(kCiphertext.size()));
  EXPECT_CALL(*mock_zero_copy_aead, Encrypt(kPlaintext, kAssociatedData, _))
      .WillOnce(Return(
          absl::Status(absl::StatusCode::kInternal, "Some error happened!")));
  AeadFromZeroCopy aead(std::move(mock_zero_copy_aead));
  EXPECT_THAT(aead.Encrypt(kPlaintext, kAssociatedData).status(),
              StatusIs(absl::StatusCode::kInternal));
}

TEST(AeadFromZeroCopyTest, DecryptSucceeds) {
  auto mock_zero_copy_aead = std::make_unique<MockZeroCopyAead>();
  EXPECT_CALL(*mock_zero_copy_aead, MaxDecryptionSize(kCiphertext.size()))
      .WillOnce(Return(kPlaintext.size()));
  EXPECT_CALL(*mock_zero_copy_aead, Decrypt(kCiphertext, kAssociatedData, _))
      .WillOnce(Invoke([&](Unused, Unused, absl::Span<char> buffer) {
        memcpy(buffer.data(), kPlaintext.data(), kPlaintext.size());
        return kPlaintext.size();
      }));

  AeadFromZeroCopy aead(std::move(mock_zero_copy_aead));
  absl::StatusOr<std::string> plaintext =
      aead.Decrypt(kCiphertext, kAssociatedData);
  ASSERT_THAT(plaintext, IsOk());
  EXPECT_EQ(*plaintext, kPlaintext);
}

TEST(AeadFromZeroCopyTest, EncryptFailsIfZeroCopyDecryptFails) {
  auto mock_zero_copy_aead = std::make_unique<MockZeroCopyAead>();
  EXPECT_CALL(*mock_zero_copy_aead, MaxDecryptionSize(kCiphertext.size()))
      .WillOnce(Return(kPlaintext.size()));
  EXPECT_CALL(*mock_zero_copy_aead, Decrypt(kCiphertext, kAssociatedData, _))
      .WillOnce(Return(
          absl::Status(absl::StatusCode::kInternal, "Some error happened!")));
  AeadFromZeroCopy aead(std::move(mock_zero_copy_aead));
  EXPECT_THAT(aead.Decrypt(kCiphertext, kAssociatedData).status(),
              StatusIs(absl::StatusCode::kInternal));
}

}  // namespace
}  // namespace internal
}  // namespace tink
}  // namespace crypto
