// linkstamp.cc
