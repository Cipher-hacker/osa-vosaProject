// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "shell_encryption/testing/protobuf_matchers.h"

#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include "shell_encryption/testing/coefficient_polynomial.pb.h"
#include "shell_encryption/testing/status_testing.h"

namespace {

TEST(EqualsProtoTest, EqualsProtoWorks) {
  rlwe::SerializedCoefficientPolynomial coeffs;
  coeffs.set_num_coeffs(10);
  EXPECT_THAT(coeffs, rlwe::testing::EqualsProto(coeffs));

  rlwe::SerializedCoefficientPolynomial coeffs_other;
  coeffs_other.set_num_coeffs(20);
  EXPECT_THAT(coeffs, ::testing::Not(rlwe::testing::EqualsProto(coeffs_other)));
}

}  // namespace
