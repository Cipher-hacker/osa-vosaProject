/*
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef RLWE_INTEGRAL_TYPES_H_
#define RLWE_INTEGRAL_TYPES_H_

#include "absl/numeric/int128.h"

namespace rlwe {

typedef uint8_t Uint8;
typedef uint16_t Uint16;
typedef uint32_t Uint32;
typedef uint64_t Uint64;

#ifdef ABSL_HAVE_INTRINSIC_INT128
typedef unsigned __int128 Uint128;
#else
typedef absl::uint128 Uint128;
#endif

}  // namespace rlwe

#endif  // RLWE_INTEGRAL_TYPES_H_
